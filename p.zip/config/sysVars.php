<?php
return [
    "cipher_secret" => "ioNsla1@312"//md5加密扰码
];