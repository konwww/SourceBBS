<?php /*a:1:{s:57:"D:\website\www\p\application\index\view\Source\index.html";i:1567855852;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>P圈</title>
    <link href="../vender/layui/css/layui.css" type="text/css" rel="stylesheet">
    <link href="/vender/layui/css/layui.css" type="text/css" rel="stylesheet">
    <!-- 让IE8/9支持媒体查询，从而兼容栅格 -->

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <!--[if lt IE 9]>
    <script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
    <script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <link href="/static/css/public.css" rel="stylesheet" type="text/css">
</head>
<body class="layui-bg-gray">
<ul class="layui-nav layui-bg-cyan">
    <li class="layui-nav-item layui-logo">
        <a href="#">P圈|LOGO|学习社区</a>
    </li>
    <li class="layui-nav-item layui-nav-item-right" onclick="toggleSideNav()">
        <a><i class="layui-icon layui-icon-shrink-right"></i></a>
    </li>
</ul>
<div class="layui-fluid">
    <div class="layui-row layui-col-space15">
        <div class="layui-col-xs12 layui-col-md12">
            <div class="layui-card p-source-main p-card-bg-black">
                <div class="layui-card-header">考研资料</div>
                <div class="layui-card-body">
                    <div class="layui-row layui-col-space35">
                        <div class="layui-col-xs12 layui-col-sm6 layui-col-md3 ">
                            <div class="layui-card p-card-bg-white p-card-source-cell">
                                <a href="./source-detail.html">
                                    <div class="layui-card-body">
                                        <img src="../static/other/img/temp1.jpg">
                                        <div class="layui-text p-card-source-cell-title">
                                            <p>考研宝典</p>
                                            <p style="font-size:x-small">张雪峰</p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="layui-col-xs12 layui-col-sm6 layui-col-md3 ">
                            <div class="layui-card p-card-bg-white p-card-source-cell">
                                <a href="#">
                                    <div class="layui-card-body">
                                        <img src="../static/other/img/temp1.jpg">
                                        <div class="layui-text p-card-source-cell-title">
                                            <p>考研宝典</p>
                                            <p style="font-size:x-small">张雪峰</p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="layui-col-xs12 layui-col-sm6 layui-col-md3 ">
                            <div class="layui-card p-card-bg-white p-card-source-cell">
                                <a href="#">
                                    <div class="layui-card-body">
                                        <img src="../static/other/img/temp1.jpg">
                                        <div class="layui-text p-card-source-cell-title">
                                            <p>考研宝典</p>
                                            <p style="font-size:x-small">张雪峰</p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="layui-col-xs12 layui-col-sm6 layui-col-md3 ">
                            <div class="layui-card p-card-bg-white p-card-source-cell">
                                <a href="#">
                                    <div class="layui-card-body">
                                        <img src="../static/other/img/temp1.jpg">
                                        <div class="layui-text p-card-source-cell-title">
                                            <p>考研宝典</p>
                                            <p style="font-size:x-small">张雪峰</p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="layui-col-xs12 layui-col-sm6 layui-col-md3 ">
                            <div class="layui-card p-card-bg-white p-card-source-cell">
                                <a href="#">
                                    <div class="layui-card-body">
                                        <img src="../static/other/img/temp1.jpg">
                                        <div class="layui-text p-card-source-cell-title">
                                            <p>考研宝典</p>
                                            <p style="font-size:x-small">张雪峰</p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="layui-col-xs12 layui-col-sm6 layui-col-md3 ">
                            <div class="layui-card p-card-bg-white p-card-source-cell">
                                <a href="#">
                                    <div class="layui-card-body">
                                        <img src="../static/other/img/temp1.jpg">
                                        <div class="layui-text p-card-source-cell-title">
                                            <p>考研宝典</p>
                                            <p style="font-size:x-small">张雪峰</p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="layui-col-xs12 layui-col-sm6 layui-col-md3 ">
                            <div class="layui-card p-card-bg-white p-card-source-cell">
                                <a href="#">
                                    <div class="layui-card-body">
                                        <img src="../static/other/img/temp1.jpg">
                                        <div class="layui-text p-card-source-cell-title">
                                            <p>考研宝典</p>
                                            <p style="font-size:x-small">张雪峰</p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="layui-col-xs12 layui-col-sm6 layui-col-md3 ">
                            <div class="layui-card p-card-bg-white p-card-source-cell">
                                <a href="#">
                                    <div class="layui-card-body">
                                        <img src="../static/other/img/temp1.jpg">
                                        <div class="layui-text p-card-source-cell-title">
                                            <p>考研宝典</p>
                                            <p style="font-size:x-small">张雪峰</p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--    分页开始-->
    <div class="layui-row layui-col-space15">
        <div class="layui-col-md12 layui-col-xs12">
            <div class="layui-card p-card-bg-black">
                <div class="layui-card-body">
                    <div class="layui-text p-page">
                        <span id="page-pre">首页</span>
                        <span id="page-first">上一页</span>
                        <span class="this">1</span>
                        <span>2</span>
                        <span>3</span>
                        <span id="page-next">下一页</span>
                        <span id="page-last">尾页</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--    页脚-->
    <div class="layui-row layui-col-space15">
        <div class="layui-col-xs12">
            <div class="layui-bg-cyan layui-card">
                <div class="layui-text layui-card-body">
                    <p>版权信息:本站版权归1771556583@qq.com所有</p>
                    <p>商业合作：请联系1771556583@qq.com</p>
                    <p>本产品中使用了layui的源代码，感谢layui的支持</p>
                </div>
            </div>
        </div>
    </div>
    <!--    页脚结束-->
</div>
<script src="../vender/layui/layui.js"></script>
<script src="/vender/layui/layui.js"></script>
<script>
    layui.use(["element", 'jquery'], function () {
        let ele = layui.element;
        let $ = layui.jquery;
    });

    function toggleSideNav() {
        layui.use(["jquery", "layer"], function () {
                let $ = layui.jquery;
                let layer = layui.layer;

            }
        );

    }
</script>
</body>
</html>