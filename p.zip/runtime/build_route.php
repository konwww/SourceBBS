<?php 
//根据 Annotation 自动生成的路由规则