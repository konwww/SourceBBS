<?php


namespace app\index\model;


use think\Model;

class Log extends Model
{

}