<?php


namespace app\index\model;


class Msg
{

}